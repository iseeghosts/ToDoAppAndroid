import React, { Component } from 'react';
import {View, Text, Image, Dimensions, SafeAreaView, TouchableHighlight, ScrollView,StyleSheet, Platform,TouchableOpacity, Button, TextInput, KeyboardAvoidingView} from 'react-native';

import UserSettingsDark from './UserSettingsDark'

import Profile_Pic from '../assets/Profile_Pic_Light.png'
import Back_Arrow from '../assets/Back_Arrow.png';

var ms = Dimensions.get('window');

export default class UserSettings extends Component {
    constructor (props) {
        super()
        this.state = ({
            oldPassword:'',
            newPassword:'',
            confirmPassword:'',
            resultText:'',
            pfv:'none',
            newMargin:props.user.taskMargin,
            theme:props.user.theme,   
            passEntry:true      
        })
    }
    set_margin = () => {
        if ((Number(this.state.newMargin)) > 0 && (Number(this.state.newMargin) < 16)) {
        this.props.user.taskMargin = Number(this.state.newMargin)
        } else {
            // alert(this.props.user.theme)
        }
    }

    /*
    password nest =>
    1. oldpassword no match => result = fail 
    2. new password empty => result = fail
    3. new password and old password match and new password confirm password match => result fail
    4. new password and old password match and new password confirm password don't match => result fail
    5. new password and confirm password don't match => result => fail
    6. oldpassword field empty => result= fail
    7. new password and old password don't match and new password confirm password match => result success
    */
    change_password = () => {
        var messages = ["old password is incorrect", "new password field/fields cannot be empty", "passwords do not match", "enter new password different than old password"]
        var text1 =''
        if ((this.state.oldPassword==this.props.user.pwd)) {

            if ((this.state.newPassword!='') && (this.state.confirmPassword == this.state.newPassword) && (this.state.newPassword != this.props.user.pwd)) {
                this.props.user.pwd = this.state.newPassword
                alert('Password Changed Successfully')
                this.setState ({
                    pfv:'none',
                    oldPassword:'',
                    newPassword:'',
                    confirmPassword:'',
                    resultText:'',  
                })
        }

        else if ((this.state.newPassword==this.state.confirmPassword) && (this.state.newPassword==this.props.oldPassword)) {
            this.setState({resultText:messages[3]})
        }

        else if ((this.state.newPassword=='') || (this.state.confirmPassword=='')) {
            text1 = messages[1]
        }
        
        else if (this.state.confirmPassword!=this.state.newPassword) {
            text1 = messages[2]
        }

    }
    
    else {
        text1 = messages[0]
    }
    this.setState({resultText:text1})
    }
    update_password = () => {
        this.setState({
            pfv:(this.state.pfv=='none'?'flex':'none'),
            oldPassword:'',
            newPassword:'',
            confirmPassword:'',
            resultText:'',  
        })        
    }
    change_theme = () => {
        this.props.user.theme = (this.props.user.theme=='light'?"dark":'light')
        this.setState({
            theme:(this.state.theme=='light'?"dark":'light'),
        })
        // alert('Logout and login to take effect')
    }

    
    render() {
        if (this.props.user.theme=='dark') {
            return (
                <View style={{flex:1}}>
                  <UserSettingsDark user={this.props.user}  closeSettings={this.props.closeSettings} />
                </View>
              )
        }
        return(
            <SafeAreaView style={styles.mainbox}>
                <KeyboardAvoidingView behavior={Platform.OS == "ios" ? "padding" : "height"}>

                    <View style={styles.backbutton}>
                        <TouchableHighlight activeOpacity={1} underlayColor="white" style={styles.backnavigation} onPress={()=> this.props.closeSettings()}>
                            <Image style={styles.buttonthumbs} source={Back_Arrow} />
                        </TouchableHighlight>
                    </View>    


                    <View style={styles.header}>
                        
                        <View style={styles.profilepiccontainer}>
                            <Image source={Profile_Pic} style={styles.picthumb} />
                        </View>

                        <View style={styles.welcometextbox}>
                            <Text style={styles.userwelcometext}> Hello {this.props.user.name}!</Text>
                        </View>

                    </View>
                    <ScrollView showsVerticalScrollIndicator={false} style={styles.settings}>

                        <View style={styles.themes}>
                            <Button onPress={() => this.update_password()} title={'Update Password'} />
                        </View>

                        {/* <TouchableOpacity activeOpacity={0.7} style={styles.passwordexpand} onPress={() => this.update_password()}>
                            <Text style={styles.passwordupdatebuttontext}>Update Password</Text>
                        </TouchableOpacity> */}
                        <View style={{display:this.state.pfv, marginHorizontal:15, marginBottom:10, borderRadius:5, flex:1, backgroundColor:'#B2B2B2'}}>
                            {/*  */}
                            <View style={styles.boxofall}>

                                <View style={styles.inputboxes}>
                                    <Text style={styles.passtext}>Enter Old Password!</Text>
                                    <TextInput style={styles.textinputpass} secureTextEntry={this.state.passEntry} placeholder={'.....'} defaultValue={this.state.oldPassword} onChangeText={(oldPassword)=>this.setState({oldPassword})} />
                                </View>

                                <View style={styles.inputboxes}>
                                    <Text style={styles.passtext}>Enter New Password!</Text>
                                    <TextInput style={styles.textinputpass} secureTextEntry={this.state.passEntry} placeholder={'.....'} defaultValue={this.state.newPassword} onChangeText={(newPassword) => this.setState({newPassword})} />
                                </View>

                                <View style={styles.inputboxes}>
                                    <Text style={styles.passtext}>Confirm your new password!</Text>
                                    <TextInput style={styles.textinputpass} secureTextEntry={this.state.passEntry} placeholder={'.....'} defaultValue={this.state.confirmPassword} onChangeText={(confirmPassword)=>this.setState({confirmPassword})} />
                                </View>

                                <Text style={styles.resulttext}>{this.state.resultText}</Text>
                            </View>
                            <Button title={'submit'} onPress={()=> this.change_password()} />

                        </View>
                        <View style={styles.themes}>
                            <View style={styles.margbox}>
                                <Text style={styles.margintext}>Enter New Margin Value (max. 15) -</Text>
                                <TextInput style={styles.marginvalue} keyboardType={'numeric'} maxLength={15} defaultValue={String(this.state.newMargin)} onChangeText={(newMargin) => this.setState({newMargin})} />
                            </View>
                            <Button title={'Update'} onPress={()=> this.set_margin()} />
                        </View>
                        <View style={styles.themes}>
                            <View style={styles.textbox}>
                                <Text style={styles.themetext}>Change Theme</Text>
                            </View>
                            <TouchableHighlight onPress={()=> this.change_theme()} style={styles.buttontbox}>
                                <Text style={styles.buttontboxtext}>{(this.state.theme=='light'?"DARK":'LIGHT')}</Text>
                            </TouchableHighlight>
                        </View>
                    </ScrollView>
                </KeyboardAvoidingView>
            </SafeAreaView>
        )
    }
}
const styles = StyleSheet.create({
    mainbox:
    {
        flex:1,
        backgroundColor:'#DBDBDB',
        alignItems:'center',
        paddingTop:10,
    },
    header:
    {
        flex:1/5,
        alignItems:'center',
        width:ms.width,
        justifyContent:'center',
        borderBottomWidth:1,
        paddingBottom:5,
    },
    backnavigation:
    {
        alignItems:'center',
        justifyContent:'center',
        backgroundColor:'white',
        borderRadius:16,
        height:32,
        width:32,
    },
    backbutton:
    {
        marginTop:20,
        marginLeft:20
    },

    buttonthumbs:{
        height:35,
        width:35,
    },
    profilepiccontainer:
    {
        marginTop:10,
        height:60,
        width:60,
        borderRadius:30,
        backgroundColor:'white',
        alignItems:'center',
        justifyContent:'center',
        elevation:2
    },
    picthumb:
    {
        height:55,
        width:55
    },
    welcometextbox:
    {
        marginTop:8,
        padding:4,
        backgroundColor:'white',
        borderRadius:5,
    },
    userwelcometext:
    {
        color:'black',
        fontSize:20
    },
    settings:
    {
        flex:4/5,
    },
    passwordupdatebuttontext:
    {
        padding:10,
        fontSize:20,
    },
    boxofall:
    {
        alignItems:'center',
        flex:1,
        backgroundColor:'#A1A1A1',
        borderRadius:5,
    },
    inputboxes:
    {
        width:ms.width*7/9,
        marginVertical:10,
        borderRadius:3,
    },
    passtext:
    {
        fontStyle:'italic',
        color:'white',
        fontSize:11,
        padding:5
    },
    textinputpass:
    {
        backgroundColor:'#686868',
        padding:10,
        color:'black',
        borderRadius:10,
    },
    resulttext:
    {
        color:'red',
        fontSize:10,
        padding:5,
    },
    margbox:{
        flexDirection:'row',
        backgroundColor:'#A1A1A1',
        borderRadius:5,
    },
    margintext:
    {
        padding:10,
        fontSize:20,
    },
    marginvalue:
    {
        color:'blue',
        width:30,
        fontSize:22,
        textDecorationLine:'underline'
    },
    themes:{
        margin:5,
        backgroundColor:'#B2B2B2',
        borderRadius:5,
        justifyContent:'center',
    },
    textbox:
    {
        backgroundColor:'#A1A1A1',
        borderRadius:5,
        padding:5
    },
    themetext:
    {
        width:ms.width-20,
        textAlign:'center',
        fontSize:20,
    },
    buttontbox:
    {
        backgroundColor:'black',
        alignItems:'center',
        justifyContent:'center',
        padding:4,
        borderRadius:5
    },
    buttontboxtext:{
        fontSize:18,
        color:'white'
    }
})
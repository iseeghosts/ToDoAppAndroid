import React, {Component} from 'react'
import {View} from 'react-native'
import WelcomeUserDark from './WelcomeUserDark'
import WelcomeUserLight from './WelcomeUserLight'

export default class WelcomeUser extends Component {
    render() {
    if (this.prop.user.theme=='light') {
        return (
            <View>
                <WelcomeUserLight user={this.props.user} openSettings={this.prop.openSettings} logout={this.props.logout}/>
            </View>
        )
        }
    
        return(
            <View>
                <WelcomeUserDark user={this.props.user} openSettings={this.prop.openSettings} logout={this.props.logout}/>
            </View>
        )
    }
}

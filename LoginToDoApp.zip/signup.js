import React, { Component } from 'react';
import {View, SafeAreaView, KeyboardAvoidingView, Platform, TouchableHigLight, StyleSheet, TextInput, Text, Dimensions} from 'react-native';

export default class SignUp extends Component {
    constructor() {
        super()
        this.state = {
            name:'',
            userid:'',
            password:'',
            displayCheck:'none',
            showPass1:true,
            showPass2:true,
            result:'',
        }
        }
        // unavailable_id = () => {            
        // }
    render() {
        var messages = ["This User ID is not available","Kindly fill the fields"];
        // this.setState({
        //     'displayCheck':(this.state.userid==""?'none':'flex')
        // })
        return( 
            <View style={styles.mainbox}>
                 <KeyboardAvoidingView behavior={Platform.OS == "ios" ? "padding" : "height"} style={styles.mainbox}>
                    <View style={styles.header}>
                        <Text style={styles.headertext}>Ready to sign up?</Text>
                    </View>
                    <View style={styles.body}>
                        <View style={styles.signupbox}>
                            <View style={styles.name}>
                                <TextInput placeholder={'Name'} paddingLeft={10} onChangeText={(name) => this.setState({name})} />
                            </View>
                            <View style={styles.useridinput}>
                                <TextInput paddingLeft={10} placeholder={'enter preferred userid!'} onChangeText={(userid) => this.setState({userid})} />
                                <Text>{this.state.result}</Text>
                            </View>
                        </View>
                    </View>
                    <View style={styles.footer}>
                        <Text>Sample footer</Text>
                    </View>
                </KeyboardAvoidingView>
            </View>
        )

    }
}

const styles = StyleSheet.create({
    mainbox:{
        flex:1,
        marginTop:10,
        // alignItems:'center',
        // justifyContent:'center'
    },
    header: {
        flex:1/10,
        backgroundColor:'lightblue',
        alignItems:'center',
        justifyContent:'center'
    },
    headertext: {
        fontStyle:'italic',
    },
    body:{
        flex:8/10,
        alignItems:'center',
        justifyContent:'center',
    },
    signupbox:{
        backgroundColor:'silver',
        alignItems:'center',
        justifyContent:'space-evenly',
        // height:90,
        paddingVertical:30,
        width:Dimensions.get('window').width*8/9,
    },
    name: {
        backgroundColor:'white',
        margin:10,
        width:Dimensions.get('window').width*8/9 - 20,
    },
    useridinput: {
        backgroundColor:'white',
        margin:10,
        width:Dimensions.get('window').width*8/9 - 20,
    },
    footer:{
        flex:1/10
    }
})
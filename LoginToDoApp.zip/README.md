# LoginToDoApp
A ToDo app with login authentication written in react native

#Notes
- This demo app was developed for iOS, which creates certain issue where some methods, properties or styles don't work as well in android as they are not available for android, for example - shadows, most of flatlist methods used in this app.
